let nav = document.querySelector("nav");


window.addEventListener("scroll", function () {
    if (window.pageYOffset > 100) {
        nav.classList.add("shadow");
        nav.classList.add("bg-primary");
        nav.classList.add("animation");
    }
    else {
        nav.classList.remove("shadow");
        nav.classList.remove("bg-primary");
        nav.classList.remove("animation");
    }
});

$(".navbar-toggler").click(function(){
    $("#inner-nav").toggleClass("border-white")
    
})